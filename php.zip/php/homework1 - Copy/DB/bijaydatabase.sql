-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2023 at 03:46 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bijaydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

DROP TABLE IF EXISTS `inquiry`;
CREATE TABLE `inquiry` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(15) NOT NULL,
  `course` varchar(300) NOT NULL,
  `city` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`id`, `firstname`, `lastname`, `email`, `dob`, `gender`, `course`, `city`, `message`, `status`, `created_at`, `updated_at`) VALUES
(1, 'dharma sir', 'poudel', 'dharm@ga.com', '2023-07-07', 'Array', '0', '', '', 0, '2023-07-07 03:05:17', '2023-07-07 08:50:17'),
(2, 'Bijayyyy', 'koirala', 'bijaykoirala162@gmail.com', '2023-07-11', 'Array', '0', '', '', 0, '2023-07-07 03:19:36', '2023-07-07 09:04:36'),
(3, 'Bibek', 'kapali', 'bibekkapali0012@gmail.com', '2003-11-11', 'Male', 'BCA', '1', ' hey i am bibek', 0, '2023-07-13 02:48:16', '2023-07-13 08:33:16'),
(4, 'Ramesh', 'khadka', 'ramesha@gmail.com', '2023-07-03', 'Male', 'BBM', '7', ' hey dude', 0, '2023-07-19 03:49:08', '2023-07-19 09:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(1) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role` varchar(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'karkineeta', 'karkti2123', 'karkineeta125@gmail.com', 'admin', 0, '2023-07-20 04:39:21', '2023-07-20 04:39:21'),
(2, 'Bijay', 'bijay@123#@', 'bijay@gmail.com', 'admin', 0, '2023-07-27 03:43:22', '2023-07-27 03:43:22'),
(8, 'user', '5f4dcc3b5aa765d61d8327deb882cf99', 'user@123gmail.com', 'admin', 1, '2023-07-28 01:00:16', '2023-07-28 01:00:16'),
(9, 'bibek', '202cb962ac59075b964b07152d234b70', 'bibel123@gmail.com', 'user', 1, '2023-07-28 01:42:29', '2023-07-28 01:42:29'),
(10, 'newuser', 'ee11cbb19052e40b07aac0ca060c23ee', 'user1@gmail.com', 'user', 1, '2023-07-28 01:43:27', '2023-07-28 01:43:27'),
(11, 'nishant djj', '0e11d184398255abe79cac2d7d7fec73', 'nish@gmail.com', 'user', 1, '2023-07-28 01:45:59', '2023-07-28 01:45:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
