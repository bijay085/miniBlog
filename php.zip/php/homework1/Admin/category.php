<?php
include("session.php");
include("inc_header.php");

echo "<a href='newcategory.php'>Add New Category<a>";
echo "<br>";
// $count=0;

$sql="SELECT * FROM category ORDER BY id DESC";
include("connection.php");

$qry=mysqli_query($conn,$sql) or die(mysqli_error($conn));
$count=mysqli_num_rows($qry);
echo "$count";

echo "<table>";
echo "<tr>";
echo "<th>SN</th>";
echo "<th>Category</th>";
echo "<th>Description</th>";
echo "<th>Status</th>";
echo "<th>Functions</th>";
echo "</tr>";

echo "</table>";
?>