<?php

//associative array : index is defined by user itself.
//associative array is defined by =>.

$names= array("bijay"=>20, "kaushal"=>22, "ramesh"=>32, "Suraj"=>12);

//printing name
echo $names["bijay"];
echo"<br>";

//printing all names with age.
foreach ($names as $i=>$v)
{
    echo "$i is $v years old <br>";
}
?>

