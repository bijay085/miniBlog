<?php

//multidimensional array in php.
//nested associative aaray if we include associative.php file.

$names=array("bijay"=>array("Age"=>20, "color"=>"White", "Height"=>5.6),
            "Saroj"=>array ("Age"=>22, "color"=>"gray", "Height"=>5.7) );

            //printing saroj height

echo $names["Saroj"]["Height"];
echo"<br>";


    
// task print all users detail vai loop.
foreach($names as $i=>$v)
{
    echo $i."<br>";
    foreach ($v as $ind => $val)
    {
        echo $ind. " " . $val. ", ";
    }
    echo "<br>";
}

?>