<?php
$names= array("bijay", "kaushal", "ramesh", "Suraj");

//printing all names using foreach loop.

foreach($names as $student)
{
echo "$student ";
}

echo "<br>";
//counting the length of array.
echo "We have total :" .count($names) . " Record <br> ";


//print all name using loop insted of foreach loop.
for($i=0; $i<count($names);$i++)
{
    echo $names[$i]. " ";
}
echo "<br>";

//add name in array.
array_push($names, "me", "you", "who");
for($i=0; $i<count($names);$i++)
{
    echo $names[$i]. " ";
}
echo "<br>";

//print_r($names) ;
//print_r is used for debbuging purpose.

//print all names in ascending order.
echo "<hr>";
sort($names);
for($i=0; $i<count($names);$i++)
{
    echo $names[$i]. " ";
}
echo "<br>";

?>